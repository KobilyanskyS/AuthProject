namespace AuthProject.API.Models.Identity;

public class RoleConsts
{
    public const string Member = "Member";
    public const string Moderator = "Moderator";
    public const string Administrator = "Administrator";
}